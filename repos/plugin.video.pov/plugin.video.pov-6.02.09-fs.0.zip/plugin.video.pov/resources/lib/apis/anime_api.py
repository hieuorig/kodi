import difflib
import re
from urllib.parse import urlparse, parse_qs
from bs4 import BeautifulSoup
from requests import Session
from caches.main_cache import main_cache
from modules.kodi_utils import get_setting, logger

DEFAULT_TIMEOUT = 30


def _find_ep_numb(eps, season, episode, flatten_episode, season_data):
    season = int(season)
    episode = int(episode)
    prev_eps = 0
    current_eps = season_data[-1]['episode_count'] if season_data else 0
    if season > 1:
        prev_eps = [s['episode_count'] for s in season_data if s['season_number'] == season - 1]
        prev_eps = prev_eps[0] if prev_eps else 0
    searched_ep = episode
    if prev_eps and prev_eps < len(eps):
        searched_ep = flatten_episode
        if len(eps) <= current_eps:
            searched_ep = episode
    return searched_ep


class Anime47Api:
    base_url = 'https://anime47.de'
    user_agent = 'Dalvik/2.1.0 (Linux; U; Android 13; Pixel 7 Pro Build/TQ1A.335336.002)'

    def __init__(self):
        url_setting = get_setting('webphim.anime47_url')
        self.url = f"https://{url_setting}" if url_setting else self.base_url
        self.session = Session()

    def search(self, title, **kwargs):
        cache_key = f"anime47_{title}_{kwargs.get('year')}"
        hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else kwargs.get('year')
        if kwargs.get('season'):
            cache_key += f"_{kwargs.get('season')}"
        try:
            link_res = main_cache.get(cache_key)
            if not link_res:
                link_res = self._search_item(title, **kwargs)
                if not link_res:
                    return
                main_cache.set(cache_key, link_res)
            link = link_res.get('link')
            kwargs.update(
                has_season=link_res.get('has_season')
            )
            episode_id = self._search_episode(link, **kwargs)

            if episode_id:
                play_url = self._get_play_link(episode_id)
                if play_url:
                    return {
                        'title': f"{title} {hdlr} 1080p Webdl",
                        "link": play_url,
                        "check": False,
                        "provider": "anime47",
                    }
        except Exception as e:
            logger('ANIME47', f'Error: {e}')
            return

    def _search_item(self, title, **kwargs):
        def _search(title):
            resp = self.session.get(f"{self.url}/tim-nang-cao/?keyword={title.replace(' ', '+')}&nam=&season=&status=&sapxep=1",
                                    headers={
                                        'User-Agent': self.user_agent,
                                        'Referer': self.url
                                    },
                                    timeout=DEFAULT_TIMEOUT)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            return soup.select('ul.last-film-box a')

        title_alias = kwargs.get('alias')
        search_title = title_alias or title
        result = []
        items = _search(search_title)
        if not items:
            if title_alias:
                items = _search(title)
        if not items:
            return
        for k in items:
            item_name = k['title'].replace('-', ' ')
            item_name_lower = item_name.lower()
            compare_name = title.replace('-', ' ')
            url = re.sub(r'^\./', self.url + '/', k.get('href'))
            if (compare_name.lower() in item_name_lower) or \
                (title_alias.lower() in item_name_lower):
                result.append(url)

        if result:
            return self._get_item_link(result[0], **kwargs)

    def _get_item_link(self, url, **kwargs):
        season = kwargs.get('season')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        }, timeout=DEFAULT_TIMEOUT)
        link = None
        has_season = False
        soup = None
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            item_link = None
            if season and int(season) > 1:
                item_info = soup.find('div', id='div1')
                if item_info and item_info.text:
                    table = item_info.find('table')
                    for row in table.find_all('tr')[1:]:
                        tds = row.find_all('td')
                        td_season = tds[1].get_text().strip().lower()
                        if 'phần' in td_season:
                            numbs = list(map(str.strip, re.sub(r'^phần\s', '', td_season).split('+')))
                            if season in numbs:
                                item_link = tds[1].find('a').get('href')
                                has_season = len(numbs) == 1
                                break
            if item_link:
                resp = self.session.get(item_link, headers={
                    'User-Agent': self.user_agent,
                })
                soup = BeautifulSoup(resp.content, 'html.parser') if resp.status_code == 200 else None
        if soup:
            watch_btn = soup.find('a', id='btn-film-watch')
            if watch_btn:
                link = re.sub(r'^\./', self.url + '/', watch_btn.get('href'))
        return dict(
            link=link,
            has_season=has_season,
        )

    def _search_episode(self, url, **kwargs):
        def _get_episode(div, episode=None):
            result_id = None
            for a in div.find_all('a'):
                if not episode:
                    result_id = a.get('data-episode-id')
                    break
                ep_name = a.get('data-episode-name')
                ep_name = re.split(r'[-_]', ep_name)[0]
                ep_str = re.sub('[^0-9]','', ep_name)
                if ep_str == str(episode).zfill(len(ep_str)):
                    result_id = a.get('data-episode-id')
                    break
            return result_id

        season = kwargs.get('season')
        episode = kwargs.get('episode')
        flatten_episode = kwargs.get('flatten_episode')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        })
        result_id = None
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, 'html.parser')
            eps_divs = soup.select('div.server div.episodes')
            seasons_divs = soup.select('div.server div.name')
            total_sections = len(eps_divs)
            if total_sections == 0:
                return result_id
            if season:
                find_season = [s for s in seasons_divs if s.get_text().strip().lower() == f'phần {season}']
                season_div = seasons_divs[0] if seasons_divs else None
                if find_season:
                    season_div = find_season[0]
                eps_div = eps_divs[0]
                if season_div:
                    eps_div = season_div.find_next_sibling('div', class_='episodes')
                if kwargs.get('has_season'):
                    result_id = _get_episode(eps_div, episode)
                else:
                    result_id = _get_episode(eps_div, flatten_episode)
                    if not result_id and str(flatten_episode) != str(episode):
                        result_id = _get_episode(eps_div, episode)
            else:
                result_id = _get_episode(eps_divs[0])
        return result_id

    def _get_play_link(self, episode_id):
        req_url = f'{self.url}/player/player.php'
        req_data = {
            'ID': episode_id,
            'SV': '4',
            'SV4': '4',
        }
        resp = self.session.post(req_url, data=req_data, headers={
            'User-Agent': self.user_agent,
            'X-Requested-With': 'XMLHttpRequest'
        })
        parts = []
        if resp.status_code == 200:
            play_link = re.search(r'"file".*?"(.*?)"', resp.text)[1]
            play_link = re.sub(r'\s+', '%20', play_link.strip(), flags=re.UNICODE)
            play_type = re.search(r'"type".*?"(.*?)"', resp.text)[1]
            if play_type.strip() == 'hls':
                parts.append('hls')
            parts.append(play_link)
            if 'subtitles' in resp.text:
                sub = re.findall(r'file:.*?"(.*?\.vtt)"', resp.text)[-1]
                parts.append(f'{self.url}{sub}')
            parts.append(f'Origin={self.url}&Referer={self.url}/&User-Agent={self.user_agent}')
        return '|'.join(parts)

class AnimeHayApi:
    base_url = 'https://animehay.biz'
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0"

    def __init__(self):
        url_setting = get_setting('webphim.animehay_url')
        self.url = f"https://{url_setting}" if url_setting else self.base_url
        self.session = Session()

    def search(self, title, **kwargs):
        try:
            hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else kwargs.get('year')
            cache_key = f"animehay_{title}_{kwargs.get('year')}"
            if kwargs.get('season'):
                cache_key += f"_{kwargs.get('season')}"
            item_link = main_cache.get(cache_key)
            if not item_link:
                item_link = self._search_item(title, **kwargs)
                if not item_link:
                    return
                main_cache.set(cache_key, item_link)
            ep_link = self._search_episode(item_link[0], **kwargs)
            if ep_link:
                play_link = self._get_play_link(ep_link)
                if play_link:
                    return {
                        'title': f"{title} {hdlr} 1080p Webdl",
                        "link": play_link,
                        "check": False,
                        "provider": "animehay",
                    }
        except Exception as e:
            logger('ANIMEHAY', f'Error: {e}')
            return

    def _search_item(self, title, **kwargs):
        def _search(title):
            resp = self.session.get(f"{self.url}/tim-kiem/{title.lower().replace(' ', '-')}.html", headers={
                'User-Agent': self.user_agent,
            }, timeout=DEFAULT_TIMEOUT)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            items = soup.select('div.movies-list div.movie-item')
            if items:
                found_idx = None
                for i, it in enumerate(items):
                    name = it.find('div', class_="name-movie").get_text().strip().lower()
                    for alias_item in aliases_list:
                        alias_ratio = difflib.SequenceMatcher(None, name, alias_item.lower()).ratio()
                        # logger('animehay', f"Comparing '{name}' with alias '{alias_item.lower()}' - Ratio: {alias_ratio}")
                        if alias_ratio > 0.7:
                            found_idx = i
                            break
                    if found_idx is not None:
                        break
                if found_idx is not None:
                    return items[found_idx]

        aliases_list = kwargs.get('aliases_list', [])
        season = kwargs.get('season')
        result = []
        items = []
        for alias in aliases_list:
            items = _search(alias)
            if items:
                break
        if not items:
            return result
        link = None
        links = items.find_all('a')
        for l in links:
            if 'thong-tin-phim' in l['href']:
                link = l['href']
                break
        if season and int(season) > 1 and link:
            resp = self.session.get(link, headers={
                'User-Agent': self.user_agent,
            })
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            seasons = soup.select('div.bind_movie a')
            for s in seasons:
                if re.search(rf'^phần {season}$', s.get_text().lower().strip()):
                    link = s['href']
                    break
        if link:
            result.append(link)
        return result

    def _search_episode(self, url, **kwargs):
        def _find_ep_flatten(ep_divs, episode):
            link = None
            for ep in ep_divs:
                ep_name =  re.split(r'[-_]', ep['title'])[0]
                ep_str = re.sub(r'\s?\(.+?\)', '', ep_name).strip()
                ep_str = re.sub('[^0-9]', '', ep_str).strip()
                if ep_str == str(episode).zfill(len(ep_str)):
                    link = ep['href']
                    break
            return link

        season = kwargs.get('season')
        episode = kwargs.get('episode')
        flatten_episode = kwargs.get('flatten_episode')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        })
        resp.raise_for_status()
        soup = BeautifulSoup(resp.content, 'html.parser')
        eps = soup.select('div.list-item-episode a')
        link = None
        if not eps:
            return link
        if not episode:
            link = eps[0]['href']
        else:
            searched_ep = _find_ep_numb(eps, season, episode, flatten_episode, kwargs.get('season_data', []))
            link = _find_ep_flatten(eps, searched_ep)
            if not link and str(searched_ep) != str(episode):
                link = _find_ep_flatten(eps, episode)

        return link

    def _get_play_link(self, url):
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
        }, timeout=DEFAULT_TIMEOUT)
        resp.raise_for_status()
        playable_link = None
        video_link = None
        video_links = re.findall(r'id=".*".*src\s*=\s*"(.*?)"', resp.text)
        for v_link in video_links[::-1]:
            if v_link and v_link.startswith('http') and self.url in v_link:
                playable_link = v_link
                break
        if playable_link:
            resp = self.session.get(playable_link, headers={
                'User-Agent': self.user_agent,
            }, timeout=DEFAULT_TIMEOUT)
            resp.raise_for_status()
            parsed_url = urlparse(playable_link)
            video_id = parse_qs(parsed_url.query)['id'][0]
            video_link = re.search(r'playlist\s*=\s*`(.*?)`;', resp.text)[1]
            video_link = video_link.replace('${id}', video_id)
        else:
            playable_link = re.search(r"\s*tik:\s*?'(.*?)'", resp.text)[1]
            if playable_link.startswith('http'):
                video_link = playable_link
        if not video_link:
            return
        return f"hls|{video_link}|Accept=*/*&Accept-Encoding=gzip&Origin={self.url}&User-Agent={self.user_agent}"

class HH3DApi:
    base_url = 'https://hoathinh3d.us'
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0"

    def __init__(self):
        self.session = Session()

    def search(self, title, **kwargs):
        try:
            cache_key = f"hh3d_{title}_{kwargs.get('year')}"
            hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else kwargs.get('year')
            if kwargs.get('season'):
                cache_key += f"_{kwargs.get('season')}"
            item_link = main_cache.get(cache_key)
            if not item_link:
                item_link = self._search_item(title, **kwargs)
                if not item_link:
                    return
                main_cache.set(cache_key, item_link)
            if not item_link:
                return
            ep_info = self._search_episode(item_link[0], **kwargs)
            if ep_info:
                play_link = self._get_play_link(ep_info, item_link[0])
                if play_link:
                    return {
                        'title': f"{title} {hdlr} 1080p Webdl",
                        "link": play_link,
                        "check": False,
                        "provider": "hoathinh3d",
                    }
        except Exception as e:
            logger('HH3D', f'Error: {e}')
            return

    def _search_item(self, title, **kwargs):
        title_alias = kwargs.get('alias')
        season = kwargs.get('season')
        search_title = title_alias or title
        resp = self.session.post(f"{self.base_url}/wp-content/themes/halimmovies/halim-ajax.php", data={
            'action': 'halim_ajax_live_search',
            'search': search_title,
        }, headers={
            'Origin': self.base_url,
            'Referer': f"{self.base_url}/",
            'User-Agent': self.user_agent,
            'X-Requested-With': 'XMLHttpRequest',
        }, timeout=15)
        link = None
        result = []
        resp.raise_for_status()
        soup = BeautifulSoup(resp.content, 'html.parser')
        items = soup.select('li.exact_result a')
        for item in items:
            item_name = item.find('span', class_="label").get_text().strip().lower()
            en_name = item.find('span', class_="enName").get_text().strip().lower()
            if search_title.lower() in item_name or search_title.lower() in en_name:
                link = item['href']
                break
        if season and link:
            resp = self.session.get(link, headers={
                'Origin': self.base_url,
                'Referer': f'{self.base_url}/',
                'User-Agent': self.user_agent,
            }, timeout=15)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.content, 'html.parser')
            seasons = soup.select('ul.list-movies-part a')
            for s in seasons:
                if f'phần {season}' in s['title'].lower().strip():
                    link = s['href']
        if link:
            result.append(link)
        return result

    def _search_episode(self, url, **kwargs):
        def _find_ep_flatten(ep_divs, episode):
            link = None
            for ep in ep_divs:
                ep_link = ep.find('a')
                ep_name =  re.split(r'[-_]', ep_link['title'])[0]
                ep_str = re.sub(r'\s?\(.+?\)', '', ep_name).strip()
                ep_str = re.sub('[^0-9]', '', ep_str).strip()
                if ep_str == str(episode).zfill(len(ep_str)):
                    link = ep
                    break
            return link

        season = kwargs.get('season')
        episode = kwargs.get('episode')
        flatten_episode = kwargs.get('flatten_episode')
        resp = self.session.get(url, headers={
            'User-Agent': self.user_agent,
            'Origin': self.base_url,
            'Referer': f'{self.base_url}/',
        }, timeout=15)
        result = None
        resp.raise_for_status()
        soup = BeautifulSoup(resp.content, 'html.parser')
        eps = (soup.select('ul.halim-list-eps li') or [])[::-1]
        ep = None
        if not episode:
            ep = eps[0]
        else:
            searched_ep = _find_ep_numb(eps, season, episode, flatten_episode, kwargs.get('season_data', []))
            ep = _find_ep_flatten(eps, searched_ep)
            if not ep and str(searched_ep) != str(episode):
                ep = _find_ep_flatten(eps, episode)
        if ep:
            ep_info = ep.find('span')
            result = {
                'post_id': ep_info['data-post-id'],
                'server_id': ep_info['data-server'],
                'subsv_id': '',
                'episode_slug': ep_info['data-episode-slug'],
            }
        return result

    def _get_play_link(self, ep_info, url):
        resp = self.session.get(f"{self.base_url}/wp-content/themes/halimmovies/player.php", params=ep_info, headers={
            'Origin': self.base_url,
            'Referer': url,
            'User-Agent': self.user_agent,
            'X-Requested-With': 'XMLHttpRequest',
        }, timeout=15)
        parts = []
        resp.raise_for_status()
        play_link = re.search(r'\\"file\\".*?\\"(.*?)\\"', resp.text)[1]
        play_link = re.sub(r'\s+', '%20', play_link.strip(), flags=re.UNICODE).replace('\\/', '/')
        play_type = re.search(r'\\"type\\".*?\\"(.*?)\\"', resp.text)[1]
        if play_type.strip() == 'hls':
            parts.append('hls')
        parts.append(play_link)
        return '|'.join(parts)
