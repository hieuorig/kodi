import requests
import re
from datetime import datetime
from requests.adapters import HTTPAdapter, Retry
from fenom import source_utils
from threading import Thread
from apis.anime_api import AnimeHayApi
from modules.utils import no_accent_vietnamese, slugify
from modules.kodi_utils import logger


def requests_retry_session(
    retries=3,
    backoff_factor=0.3,
    status_forcelist=(429, 500, 502, 503, 504),
    session=None,
):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session


class OPhim:
    base_url = 'https://ophim1.com'
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.0.0'

    def __init__(self):
        self.session = requests.Session()
        self.provider = 'ophim'
        self.search_url = f'{self.base_url}/v1/api/tim-kiem'
        self.phim_url = f'{self.base_url}/phim'
        self.item_origin_name = 'origin_name'
        self.item_data = 'server_data'
        self.item_server_name = 'server_name'
        self.item_link = 'link_m3u8'
        self.headers = {
            'Accept': '*/*',
            'User-Agent': self.user_agent,
        }

    def search(self, title, **kwargs):
        def _search(title):
            resp_data = requests_retry_session(self.session).get(self.search_url, params={
                'keyword': title
            }, headers=self.headers, timeout=15)
            resp_data.raise_for_status()
            data = resp_data.json() if resp_data else None
            if ('data' in data and data['data'].get('items')) or 'items' in data:
                if 'items' in data:
                    return data
                return data.get('data')
            return None

        def _check_aliases(aliases, compare_titles):
            for alias in aliases:
                if alias.lower() in compare_titles:
                    return True
            return False

        try:
            alias = kwargs.get('alias') or ''
            aliases_list = kwargs.get('aliases_list', [alias, title])
            year = int(kwargs.get('year'))
            season = kwargs.get('season')
            hdlr = 'S%02dE%02d' % (int(kwargs.get('season')), int(kwargs.get('episode'))) if kwargs.get('season') else year
            for alias in aliases_list:
                data = _search(alias)
                if data and data['items']:
                    break
            if not data or not data.get('items', []):
                return
            items = data.get('items', [])
            slug = None
            link = None
            season_names = None
            season_year = year
            if season:
                cur_s = [s for s in kwargs.get('season_data', []) if s.get('season_number') == int(season)]
                if cur_s:
                    release_date = cur_s[0].get('air_date')
                    season_year = int(datetime.strptime(release_date, '%Y-%m-%d').year) if release_date else year
                if int(season) > 1:
                    season_names = [f"{title.lower()} {season}", f"{title.lower()} (season {season})"]
                    if alias:
                        season_names.append(f"{alias.lower()} {season}")
            for i in items:
                if season and 'total_episodes' in i and i.get('total_episodes') == 1:
                    continue
                name = re.sub(r'\s?\(.+?\)', '', i.get('name').split(' - ')[0]).strip()
                orig_name = re.sub(r'\s?\(.+?\)', '', i.get(self.item_origin_name).split('/')[-1]).strip()
                names = [name.lower(), orig_name.lower()]
                orig_names = [i.get('name').lower(), i.get(self.item_origin_name).lower()]
                release_year = i.get('year', season_year)
                if season and 'tmdb' in i and i['tmdb'].get('season') == season:
                    slug = i.get('slug')
                    break
                if season_names and (i.get('name').lower() in season_names or i.get(self.item_origin_name).lower() in season_names):
                    slug = i.get('slug')
                    break
                if _check_aliases(aliases=aliases_list, compare_titles=names if not season else orig_names) and (release_year == season_year or release_year == season_year - 1):
                    slug = i.get('slug')
                    break
            if slug:
                link = self._get_link(slug, **kwargs)
            if link:
                r = []
                for k, v in link.items():
                    r.append({
                        'title': f'{title} {hdlr} {k} 1080p webdl',
                        'link': v if self.provider == 'nguonc' else f"hls|{v}",
                        'provider': self.provider,
                    })
                return r
        except Exception as e:
            logger(self.provider, f'Error: {e}')

    def _get_link(self, slug, **kwargs):
        episode = kwargs.get('episode')
        resp_data = requests_retry_session(self.session).get(f'{self.phim_url}/{slug}', headers=self.headers, timeout=15)
        resp_data.raise_for_status()
        data = resp_data.json() if resp_data else None
        if data is None:
            return
        if 'movie' in data and 'episodes' not in data:
            data = data.get('movie')
        try:
            results = {}
            for server in data.get('episodes', []):
                server_name = server.get(self.item_server_name)
                episodes = server.get(self.item_data, [])
                if not episode:
                    results[no_accent_vietnamese(server_name)] = episodes[0].get(self.item_link)
                else:
                    for ep in episodes:
                        e_no = slugify(no_accent_vietnamese(ep.get('name', '').strip()))
                        if e_no.startswith('tap-'):
                            e_no = e_no.replace('tap-', '')
                        e_no = re.sub(r'^0+(\d)', r'\1', e_no)
                        e_range = []
                        if '-' in e_no:
                            e_range = e_no.split('-', 1)
                        if e_no == episode or (e_range and int(episode) in range(int(e_range[0]), int(e_range[1]))):
                            results[no_accent_vietnamese(server_name)] = ep.get(self.item_link)
                            break
            return results if results.values() else None
        except: pass

class Nguonc(OPhim):
    base_url = 'https://phim.nguonc.com'

    def __init__(self):
        super().__init__()
        self.provider = 'nguonc'
        self.search_url = f'{self.base_url}/api/films/search'
        self.phim_url = f'{self.base_url}/api/film'
        self.item_origin_name = 'original_name'
        self.item_data = 'items'
        self.item_link = 'embed'

class KKPhim(OPhim):
    base_url = 'https://phimapi.com'

    def __init__(self):
        super().__init__()
        self.provider = 'kkphim'

class source:
    priority = 5
    pack_capable = False
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en', 'vi']
        self.ophim_api = OPhim()
        self.kkphim_api = KKPhim()
        self.nguonc = Nguonc()
        self.animehay = AnimeHayApi()

    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        append = sources.append
        try:
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            episode_title = data['title'] if 'tvshowtitle' in data else None
            aliases = data.get('aliases') or []
            aliases_list = [a['title'] for a in aliases]
            alias = aliases_list[0] if aliases_list else None
            year = data.get('year')
            season = data.get('season')
            episode = data.get('episode')
            genres = data.get('genres', [])
            season_data = data.get('season_data', [])
            hdlr = 'S%02dE%02d' % (int(season), int(episode)) if 'tvshowtitle' in data else year
            flatten_episode = 0
            for s in sorted(season_data, key=lambda d: d['season_number']):
                season_number = s.get('season_number')
                episode_count = s.get('episode_count')
                if season_number == 0:
                    continue
                if season_number < int(season):
                    flatten_episode += episode_count
                elif season_number == int(season):
                    flatten_episode += int(episode)
                    break
            search_extra = dict(
                year=year,
                season=season,
                episode=episode,
                flatten_episode=flatten_episode if flatten_episode > 0 else None,
                season_data=season_data,
                alias=alias,
                aliases_list=aliases_list,
            )

            results = []
            threads = []
            for search_func in [self._search_nguonc, self._search_ophim, self._search_kkphim]:
                threads.append(Thread(target=search_func, args=(title, results), kwargs=search_extra))
            for genre in genres:
                if genre.lower() in ['anime', 'phim hoạt hình', 'animation']:
                    threads.append(Thread(target=self._search_animehay, args=(title, results), kwargs=search_extra))
                    break
            for t in threads:
                t.start()
            for t in threads:
                t.join()

            logger('WEBPHIM', f'[Scrape] {title}: {len(results)}')
            for item in results:
                url = item.get('link')
                raw_name = item['title'].lower()
                name = source_utils.clean_name(raw_name)
                name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                quality, info = source_utils.get_release_quality(name_info, url)
                try:
                    dsize, isize = source_utils.convert_size(float(item["size"]), to='GB')
                    info.insert(0, isize)
                except:
                    dsize = 0
                info = ' | '.join(info)

                append({'provider': 'webphim', 'source': item.get('provider', 'hoster'), 'name': name, 'name_info': name_info,
                        'quality': quality, 'language': 'vi', 'url': url, 'info': info,
                        'direct': True, 'debridonly': False, 'size': dsize})
        except Exception as e:
            logger('WEBPHIM', f"Error: {e}")
            source_utils.scraper_error('WEBPHIM')
        return sources

    def _search_ophim(self, title, result, **kwargs):
        link = self.ophim_api.search(title, **kwargs)
        if link:
            result.extend(link)
        return [link]

    def _search_kkphim(self, title, result, **kwargs):
        link = self.kkphim_api.search(title, **kwargs)
        if link:
            result.extend(link)
        return [link]
    
    def _search_nguonc(self, title, result, **kwargs):
        link = self.nguonc.search(title, **kwargs)
        if link:
            result.extend(link)
        return [link]

    def _search_animehay(self, title, result, **kwargs):
        link = self.animehay.search(title, **kwargs)
        if link:
            result.extend([link])
        return [link]
